package com.bezkoder.spring.login.controllers;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import com.bezkoder.spring.login.exception.ResourceNotFoundException;
import com.bezkoder.spring.login.models.Template;
import com.bezkoder.spring.login.repository.TemplateRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.bezkoder.spring.login.security.services.TemplateService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class TemplateController {
    @Autowired
    private TemplateRepository templateRepository;
    @Autowired
    private TemplateService templateService;

    @PostMapping("/templates")
    public Template createTemplate(@Valid @RequestBody Template template) {
        return templateRepository.save(template);

    }

    @GetMapping("/templates")
    public List<Template> getAllTemplates() {
        return templateRepository.findAll();
    }

    @GetMapping("/templates/{id}")
    public ResponseEntity<Template> gettemplateById(@PathVariable(value = "id") Long templateId)
            throws ResourceNotFoundException {
        Template template = templateRepository.findById(templateId)
                .orElseThrow(() -> new ResourceNotFoundException("Template not found for this id :: " + templateId));
        return ResponseEntity.ok().body(template);
    }

    @GetMapping("/templates/user/{userId}")
    public ResponseEntity<List<Template>> getTemplatesByUserId(@PathVariable Long userId) {
        List<Template> templates = templateService.getTemplatesByUserId(userId);
        return ResponseEntity.ok(templates);
    }

    @PutMapping("/templates/{id}")
    public ResponseEntity<Template> updateTemplate(@PathVariable(value = "id") Long templateId,
            @Valid @RequestBody Template templateDetails) throws ResourceNotFoundException {
        Template template = templateRepository.findById(templateId)
                .orElseThrow(() -> new ResourceNotFoundException("template not found for this id :: " + templateId));

        template.setName(templateDetails.getName());
        // template.setUserId(templateDetails.getUserId());
        template.setTemplate(templateDetails.getTemplate());
        // template.setTemplateState(templateDetails.getTemplateState());
        final Template updatedTemplate = templateRepository.save(template);
        return ResponseEntity.ok(updatedTemplate);
    }

    @DeleteMapping("/templates/{id}")
    public Map<String, Boolean> deleteTemplate(@PathVariable(value = "id") Long templateId)
            throws ResourceNotFoundException {
        Template template = templateRepository.findById(templateId)
                .orElseThrow(() -> new ResourceNotFoundException("template not found for this id :: " + templateId));

        templateRepository.delete(template);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

}

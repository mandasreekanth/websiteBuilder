// package com.bezkoder.spring.login.security.services;

// public class TemplateDetails {

// }

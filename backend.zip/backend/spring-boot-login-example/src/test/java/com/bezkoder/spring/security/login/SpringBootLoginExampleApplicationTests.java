package com.bezkoder.spring.security.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLoginExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

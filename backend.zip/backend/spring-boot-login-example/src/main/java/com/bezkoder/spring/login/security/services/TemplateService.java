package com.bezkoder.spring.login.security.services;

import javax.persistence.Id;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.login.models.Template;
import com.bezkoder.spring.login.repository.TemplateRepository;
import java.util.List;

@Service
public class TemplateService {
    @Autowired
    private TemplateRepository templateRepository;

    public List<Template> getTemplatesByUserId(Long userId) {
        return templateRepository.findByUserId(userId);
    }
}

package com.bezkoder.spring.login.models;

import java.io.IOException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Transient;

import org.springframework.lang.NonNull;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Entity
public class Template {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String template;
    private Long userId;
    @Column(columnDefinition = "json")
    private String metadata;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    // public Object getTemplateState() {
    // return templateState;
    // }

    // public void setTemplateState(Object object) {
    // this.templateState = object;
    // }

    // public JsonNode gettemplateState() {
    // return templateState;
    // }

    // public void settemplateState(JsonNode templateState) {
    // this.templateState = templateState;
    // }

    // @Column(name = "json_column")
    // public String getJsonColumn() {
    // return this.templateState.toString();
    // }

    // public void setJsonColumn(String jsonColumn) throws IOException {
    // ObjectMapper mapper = new ObjectMapper();
    // this.templateState = mapper.readTree(jsonColumn);
    // }

    // @Override
    // public String toString() {
    // return String
    // }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}

/*
 * 
 * package com.bezkoder.spring.login.models;
 * 
 * import java.io.IOException;
 * 
 * import javax.persistence.Column;
 * import javax.persistence.Entity;
 * import javax.persistence.GeneratedValue;
 * import javax.persistence.GenerationType;
 * import javax.persistence.Id;
 * import javax.persistence.Transient;
 * 
 * import com.fasterxml.jackson.databind.JsonNode;
 * import com.fasterxml.jackson.databind.ObjectMapper;
 * 
 * @Entity
 * public class Template {
 * 
 * @Id
 * 
 * @GeneratedValue(strategy = GenerationType.IDENTITY)
 * private Long id;
 * private String name;
 * private String templates;
 * private TemplateState templateState;
 * // @Embedded
 * // private Object templateState;
 * 
 * private Long userId;
 * 
 * public class TemplateState {
 * private String templateName;
 * private boolean isDetailView;
 * private String currentSection;
 * private String backgroundColor;
 * private PageContent pageContent;
 * 
 * // getters and setters
 * }
 * 
 * public class PageContent {
 * private PageTitle pageTitle;
 * private TitleText titleText;
 * private SubTitle1 subTitle1;
 * private SubText1 subText1;
 * private SubTitle2 subTitle2;
 * private SubText2 subText2;
 * private Footer footer;
 * 
 * // getters and setters
 * }
 * 
 * public class PageTitle {
 * private String name;
 * private String text;
 * private String style;
 * private String color;
 * private String backgroundColor;
 * private String font;
 * private int fontSize;
 * private String fontStyle;
 * 
 * // getters and setters
 * }
 * 
 * public class TitleText {
 * private String name;
 * private String text;
 * private String style;
 * private String color;
 * private String backgroundColor;
 * private String font;
 * private int fontSize;
 * private String fontStyle;
 * 
 * // getters and setters
 * }
 * 
 * public class SubTitle1 {
 * private String name;
 * private String text;
 * private String style;
 * private String color;
 * private String backgroundColor;
 * private String font;
 * private int fontSize;
 * private String fontStyle;
 * 
 * // getters and setters
 * }
 * 
 * public class SubText1 {
 * private String name;
 * private String text;
 * private String style;
 * private String color;
 * private String backgroundColor;
 * private String font;
 * private int fontSize;
 * private String fontStyle;
 * 
 * // getters and setters
 * }
 * 
 * public class SubTitle2 {
 * private String name;
 * private String text;
 * private String style;
 * private String color;
 * private String backgroundColor;
 * private String font;
 * private int fontSize;
 * private String fontStyle;
 * 
 * // getters and setters
 * }
 * 
 * public class SubText2 {
 * private String name;
 * private String text;
 * private String style;
 * private String color;
 * private String backgroundColor;
 * private String font;
 * private int fontSize;
 * private String fontStyle;
 * 
 * // getters and setters
 * }
 * 
 * public class Footer {
 * private String style;
 * 
 * // getters and setters
 * }
 * 
 * public Long getId() {
 * return id;
 * }
 * 
 * public void setId(Long id) {
 * this.id = id;
 * }
 * 
 * public String getName() {
 * return name;
 * }
 * 
 * public void setName(String name) {
 * this.name = name;
 * }
 * 
 * public String getTemplate() {
 * return templates;
 * }
 * 
 * public void setTemplate(String templates) {
 * this.templates = templates;
 * }
 * 
 * // public Object getTemplateState() {
 * // return templateState;
 * // }
 * 
 * // public void setTemplateState(Object object) {
 * // this.templateState = object;
 * // }
 * 
 * // public JsonNode gettemplateState() {
 * // return templateState;
 * // }
 * 
 * // public void settemplateState(JsonNode templateState) {
 * // this.templateState = templateState;
 * // }
 * 
 * public Long getUserId() {
 * return userId;
 * }
 * 
 * public void setUserId(Long userId) {
 * this.userId = userId;
 * }
 * }
 * 
 */